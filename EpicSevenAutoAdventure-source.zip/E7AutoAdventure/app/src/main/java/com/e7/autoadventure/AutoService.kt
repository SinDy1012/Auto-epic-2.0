package com.e7.autoadventure

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button

class AutoService : AccessibilityService() {
 companion object { var instance: AutoService? = null }
 private val handler = Handler(Looper.getMainLooper())
 private var running = false
 private var bubble: Button? = null
 private var windowManager: WindowManager? = null
 override fun onServiceConnected() { super.onServiceConnected(); instance = this }
 override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
 override fun onInterrupt() { stop() }
 override fun onDestroy() { stop(); bubble?.let { windowManager?.removeView(it) }; bubble = null; instance = null; super.onDestroy() }
 fun showBubble() {
  if (bubble != null) return
  if (!android.provider.Settings.canDrawOverlays(this)) return
  windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
  val btn = Button(this).apply { text = "Bắt đầu"; setOnClickListener { if (running) stop() else start() } }
  val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 180 }
  windowManager?.addView(btn, params); bubble = btn
 }
 private fun start() { running = true; bubble?.text = "Dừng"; /* Không tự chạm bừa: cần cấu hình nhận diện trước khi kích hoạt */ }
 private fun stop() { running = false; bubble?.text = "Bắt đầu"; handler.removeCallbacksAndMessages(null) }
 fun tap(x: Float, y: Float) { if (!running) return; val path = Path().apply { moveTo(x,y) }; val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,80)).build(); dispatchGesture(gesture,null,null) }
}
