package com.e7.autoadventure

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32,48,32,24) }
  val info = TextView(this).apply { text = "Epic Seven Auto Adventure\n\nBản thử nghiệm: nút nổi và thao tác chạm thử. Chưa tự nhận diện và vượt map hoàn chỉnh."; textSize = 18f }
  layout.addView(info)
  fun addButton(text: String, click: () -> Unit) { layout.addView(Button(this).apply { this.text = text; setOnClickListener { click() } }) }
  addButton("1. Cấp quyền hiển thị trên ứng dụng khác") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
  addButton("2. Bật Trợ năng cho Epic Seven Auto Adventure") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
  addButton("3. Hiện nút nổi Bắt đầu / Dừng") { AutoService.instance?.showBubble() ?: run { info.text = "Hãy bật Trợ năng ở bước 2 rồi quay lại ứng dụng." } }
  setContentView(layout)
 }
}
